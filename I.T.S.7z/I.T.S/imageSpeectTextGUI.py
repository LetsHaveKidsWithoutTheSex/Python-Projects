from tkinter import *
import tkinter
import sys
from io import StringIO
from tkinter import filedialog
import tkinter.font as font
import tkinter as tk
import pytesseract  # convert the image to text string
from PIL import Image  # adds image processing capabilities
import pyttsx3  # converts the text to speech
from googletrans import Translator  # translates into the mentioned language

guiMain = Tk()
guiMain.title("I.T.S. Image to Text to Speech")
guiMain.iconbitmap('GUI/ITS.ico')
guiMain.geometry('450x250')
guiMain.resizable(width=False, height=False)
novafont = font.Font(family='Nova Square', size=36)

# variables


def load_file():
    filename = filedialog.askopenfilename(filetypes=[("PNG", "*.png"), ("JPEG", "*.jpg"), ("All Files", "*.*")])
    pytesseract.pytesseract.tesseract_cmd = 'E:/Programs/Tesseract-OCR/tesseract.exe'
    result = pytesseract.image_to_string(filename)
    with open('output.txt', mode='w', encoding='utf-8') as file:

        file.write(result)
        print(result)


def speechModule():
    p = Translator()  # translates to native language via googletrans api
    k = p.translate(load_file.result)  # this needs to call to the file being opened

    print(k)

    engine = pyttsx3.init()
    engine.say(k)  # audio engine which speaks the input image if pyttsx3 recognizes it
    engine.runAndWait()

# buttons


LOAD = Button(guiMain, text='LOAD', height=4, width=5, fg='white', bg='#343BA6', command=load_file)
LOAD['font'] = novafont
LOAD.grid(row=0, column=0)

TALK = Button(guiMain, text='TALK', height=4, width=5, fg='white', bg='#343BA6', command=speechModule)
TALK['font'] = novafont
TALK.grid(row=0, column=1)


QUIT = Button(guiMain, text='QUIT', height=4, width=5, fg='white', bg='#343BA6', command=guiMain.destroy)
QUIT['font'] = novafont
QUIT.grid(row=0, column=2)

guiMain.mainloop()
